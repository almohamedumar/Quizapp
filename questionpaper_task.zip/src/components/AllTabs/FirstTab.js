import React from "react";
import Quiz from '../QuizMain';
const FirstTab = () => {
  return (
    <div className="FirstTab">
      <Quiz />  
    </div>
  );
};
export default FirstTab;