import React from "react";
import Quiz from '../QuizMain2';
const ThirdTab = () => {
  return (
    <div className="ThirdTab">
      <Quiz/>
    </div>
  );
};
export default ThirdTab;