import React from "react";
import Quiz from '../QuizMain1';
const SecondTab = () => {
  return (
    <div className="SecondTab">
      <Quiz/>
    </div>
  );
};
export default SecondTab;