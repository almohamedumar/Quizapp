import React, {createContext} from "react";

const TabContext = createContext();

export default TabContext;